package com.example.lucere;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<ProductModel> productList; // List to store product data

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Set LayoutManager for vertical scrolling

        // Fetch product data
        fetchProductList();
    }

    private void fetchProductList() {
        ProductService productService = RetrofitClient.getInstance().getProductService();

        Call<List<ProductModel>> call = productService.getAllProducts();
        call.enqueue(new Callback<List<ProductModel>>() {
            @Override
            public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    productList = response.body(); // Get the list of products
                    setupRecyclerView(productList);
                } else {
                    Log.e("ProductListActivity", "Error fetching products: " + response.code());
                    Toast.makeText(ProductListActivity.this, "Failed to load products.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                Log.e("ProductListActivity", "Network failure: " + t.getMessage());
                Toast.makeText(ProductListActivity.this, "Network error. Please try again.", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void setupRecyclerView(List<ProductModel> products) {
        if (products != null) {
            productAdapter = new ProductAdapter(products);
            recyclerView.setAdapter(productAdapter);
        }
    }
}
