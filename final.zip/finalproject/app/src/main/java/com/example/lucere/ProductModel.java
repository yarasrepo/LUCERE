package com.example.lucere;

import java.util.List;

public class ProductModel {
    private String product_name; // The name of the product
    private String product_url;  // URL for the product
    private String product_type; // The type/category of the product
    private List<String> clean_ingreds; // List of clean ingredients

    // Getters and Setters
    public String getProductName() {
        return product_name;
    }


    public String getProductUrl() {
        return product_url;
    }


    public String getProductType() {
        return product_type;
    }


}
